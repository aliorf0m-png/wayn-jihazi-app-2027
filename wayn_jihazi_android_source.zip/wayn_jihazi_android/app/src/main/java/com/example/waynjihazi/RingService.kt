package com.example.waynjihazi

import android.app.*
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder

class RingService : Service() {
    private var player: MediaPlayer? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopRinging()
            else -> startRinging()
        }
        return START_NOT_STICKY
    }

    private fun startRinging() {
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("وين جهازي؟")
            .setContentText("جهازك قاعد يرن — افتح التطبيق لإيقاف الرنين")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setOngoing(true)
            .build()
        startForeground(41, notification)
        if (player?.isPlaying == true) return
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            player = MediaPlayer().apply {
                setDataSource(this@RingService, uri)
                isLooping = true
                setVolume(1f, 1f)
                prepare()
                start()
            }
        } catch (_: Exception) {
            stopSelf()
        }
    }

    private fun stopRinging() {
        try { player?.stop() } catch (_: Exception) { }
        player?.release()
        player = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID, "تنبيه العثور على الجهاز",
                NotificationManager.IMPORTANCE_HIGH
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        try { player?.release() } catch (_: Exception) { }
        player = null
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.example.waynjihazi.START_RING"
        const val ACTION_STOP = "com.example.waynjihazi.STOP_RING"
        const val CHANNEL_ID = "device_finder_ring"
    }
}
