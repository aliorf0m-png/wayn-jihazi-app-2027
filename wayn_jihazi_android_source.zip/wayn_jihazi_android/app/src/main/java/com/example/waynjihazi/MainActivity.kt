package com.example.waynjihazi

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.functions.FirebaseFunctions

class MainActivity : AppCompatActivity() {
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val db by lazy { FirebaseDatabase.getInstance().reference }
    private lateinit var status: TextView
    private lateinit var codeView: TextView
    private lateinit var codeInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestNotificationPermission()
        buildScreen()
        signInAndRegister()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
            setBackgroundColor(0xFF090909.toInt())
        }
        val brand = TextView(this).apply {
            text = "وِين جِهَازِي؟"
            textSize = 29f
            setTextColor(0xFFD7BD82.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "تحكم بأجهزتك المرتبطة بأمان"
            textSize = 14f
            setTextColor(0xFF9A9A9A.toInt())
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "جاري تجهيز الاتصال..."
            textSize = 14f
            setTextColor(0xFFBFA36A.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 28, 0, 18)
        }
        codeView = TextView(this).apply {
            text = "------"
            textSize = 34f
            letterSpacing = 0.22f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        val makeCode = button("إنشاء كود ربط") { createPairingCode() }
        codeInput = EditText(this).apply {
            hint = "اكتب كود الجهاز الثاني"
            setHintTextColor(0xFF777777.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            textSize = 16f
            gravity = Gravity.CENTER
            setSingleLine()
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setBackgroundColor(0xFF202020.toInt())
        }
        val pair = button("ربط بهذا الجهاز") { pairDevice() }
        val ring = button("رن جهازي المرتبط") { sendRingCommand() }
        val stop = button("إيقاف الرنين") { sendStopCommand() }
        page.addView(brand)
        page.addView(subtitle)
        page.addView(status)
        page.addView(codeView)
        page.addView(makeCode)
        page.addView(space())
        page.addView(codeInput, LinearLayout.LayoutParams(-1, 58))
        page.addView(pair)
        page.addView(space())
        page.addView(ring)
        page.addView(stop)
        val note = TextView(this).apply {
            text = "لازم توافق على الربط من الجهازين. الرنين يعتمد على إشعارات أندرويد واتصال الإنترنت وقد يتأثر بوضع عدم الإزعاج."
            textSize = 12f
            setTextColor(0xFF777777.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 26, 0, 0)
        }
        page.addView(note)
        setContentView(page)
    }

    private fun space() = TextView(this).apply { height = 12 }

    private fun button(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(0xFF111111.toInt())
        setBackgroundColor(0xFFD7BD82.toInt())
        textSize = 15f
        setOnClickListener { action() }
        val p = LinearLayout.LayoutParams(-1, 54)
        p.topMargin = 10
        layoutParams = p
    }

    private fun signInAndRegister() {
        if (auth.currentUser != null) {
            registerToken()
            status.text = "الجهاز جاهز للربط"
        } else {
            auth.signInAnonymously().addOnSuccessListener {
                registerToken()
                status.text = "تم الاتصال — أنشئ كود ربط"
            }.addOnFailureListener {
                status.text = "تعذر الاتصال — تأكد من إعداد Firebase"
            }
        }
    }

    private fun registerToken() {
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            auth.currentUser?.uid?.let { uid ->
                db.child("devices").child(uid).child("fcmToken").setValue(token)
            }
        }
    }

    private fun createPairingCode() {
        status.text = "جاري إنشاء كود آمن..."
        FirebaseFunctions.getInstance().getHttpsCallable("createPairingCode").call()
            .addOnSuccessListener { result ->
                val data = result.data as? Map<*, *>
                val code = data?.get("code") as? String
                if (code != null) {
                    codeView.text = code
                    status.text = "شارك الكود مع جهازك الثاني — صالح لمدة 5 دقائق"
                } else {
                    status.text = "ما وصلنا كود من الخادم"
                }
            }
            .addOnFailureListener {
                status.text = "تعذر إنشاء الكود — تأكد من نشر Cloud Functions"
            }
    }

    private fun pairDevice() {
        val code = codeInput.text.toString().trim()
        if (code.length != 6) {
            codeInput.error = "الكود لازم يكون 6 أرقام"
            return
        }
        status.text = "جاري ربط الجهازين..."
        FirebaseFunctions.getInstance().getHttpsCallable("pairWithCode")
            .call(mapOf("code" to code))
            .addOnSuccessListener {
                status.text = "تم ربط الجهازين بنجاح"
                codeInput.text?.clear()
            }
            .addOnFailureListener {
                status.text = "فشل الربط — تأكد من صحة الكود وأنه ما انتهى"
            }
    }

    private fun sendRingCommand() = sendCommand("ring")
    private fun sendStopCommand() = sendCommand("stop")

    private fun sendCommand(command: String) {
        val uid = auth.currentUser?.uid ?: run {
            status.text = "انتظر لين يكتمل الاتصال"
            return
        }
        db.child("links").child(uid).get().addOnSuccessListener { snap ->
            val peer = snap.child("peerUid").getValue(String::class.java)
            if (peer.isNullOrBlank()) {
                status.text = "اربط جهاز ثاني أول"
                return@addOnSuccessListener
            }
            db.child("devices").child(peer).child("command").setValue(
                mapOf("type" to command, "from" to uid, "at" to System.currentTimeMillis())
            ).addOnSuccessListener {
                status.text = if (command == "ring") "تم إرسال طلب الرنين" else "تم إرسال طلب الإيقاف"
            }.addOnFailureListener {
                status.text = "ما قدرنا نرسل الأمر"
            }
        }
    }

    private fun requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }
}
