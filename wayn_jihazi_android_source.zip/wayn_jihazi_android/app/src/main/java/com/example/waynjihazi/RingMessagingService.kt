package com.example.waynjihazi

import android.content.Intent
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class RingMessagingService : FirebaseMessagingService() {
    override fun onMessageReceived(message: RemoteMessage) {
        when (message.data["type"]) {
            "ring" -> {
                val intent = Intent(this, RingService::class.java).setAction(RingService.ACTION_START)
                try { startForegroundService(intent) } catch (_: Exception) { }
            }
            "stop" -> {
                val intent = Intent(this, RingService::class.java).setAction(RingService.ACTION_STOP)
                try { startService(intent) } catch (_: Exception) { }
            }
        }
    }

    override fun onNewToken(token: String) {
        // MainActivity refreshes the token on next launch. For production, persist it here too.
    }
}
