const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onValueCreated } = require("firebase-functions/v2/database");
const { initializeApp } = require("firebase-admin/app");
const { getDatabase } = require("firebase-admin/database");
const { getMessaging } = require("firebase-admin/messaging");
const crypto = require("crypto");

initializeApp();

// Creates a short-lived one-time code on the server.
exports.createPairingCode = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first");
  const uid = request.auth.uid;
  const code = String(crypto.randomInt(100000, 1000000));
  const db = getDatabase();
  await db.ref(`pairingCodes/${code}`).set({
    ownerUid: uid,
    expiresAt: Date.now() + 5 * 60 * 1000
  });
  return { code, expiresInSeconds: 300 };
});

// The second device calls this after the owner shares the code with them.
// Both users must be signed in and the code expires after five minutes.
exports.pairWithCode = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "Sign in first");
  const code = String(request.data?.code || "");
  if (!/^\d{6}$/.test(code)) throw new HttpsError("invalid-argument", "Invalid code");
  const db = getDatabase();
  const codeRef = db.ref(`pairingCodes/${code}`);
  const result = await codeRef.transaction(value => {
    if (!value || value.used || value.expiresAt < Date.now() || value.ownerUid === request.auth.uid) return;
    return { ...value, used: true };
  });
  if (!result.committed || !result.snapshot.exists())
    throw new HttpsError("not-found", "Code expired or invalid");
  const ownerUid = result.snapshot.val().ownerUid;
  const peerUid = request.auth.uid;
  const updates = {};
  updates[`links/${ownerUid}/peerUid`] = peerUid;
  updates[`links/${peerUid}/peerUid`] = ownerUid;
  updates[`pairingCodes/${code}`] = null;
  await db.ref().update(updates);
  return { paired: true };
});

// When a linked device writes a command, send a high-priority data message.
exports.forwardDeviceCommand = onValueCreated(
  "/devices/{deviceUid}/command",
  async (event) => {
    const targetUid = event.params.deviceUid;
    const command = event.data.val();
    if (!command || !["ring", "stop"].includes(command.type)) return;
    const db = getDatabase();
    const [linkSnap, tokenSnap] = await Promise.all([
      db.ref(`links/${targetUid}/peerUid`).get(),
      db.ref(`devices/${targetUid}/fcmToken`).get()
    ]);
    const senderUid = command.from;
    if (!linkSnap.exists() || linkSnap.val() !== senderUid) return;
    const token = tokenSnap.val();
    if (!token) return;
    await getMessaging().send({
      token,
      data: { type: command.type },
      android: { priority: "high", ttl: 60 * 1000 }
    });
    await event.data.ref.remove();
  }
);
